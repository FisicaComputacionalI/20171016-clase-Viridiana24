# Plot2DWithPython
Código inicial para gráfica 2D con python

El primer ejercicio es usar el código de ejemplo en este repositorio, el mismo código que usamos en claso, y graficar el número total de hermanos y primos que has tenido en tus años de vida. La priemra entrada de la gráfica sería al nacer (0) y después cada año de vida correspondería a una entrada. Colocar el código y la gráfica que resulte en el repositorio que se crea al aceptar esta tarea.

El tiempo para entregar la tarea es el sábado a las 23:00.
